// Smooth scrolling for navigation links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        document.querySelector(this.getAttribute('href')).scrollIntoView({
            behavior: 'smooth'
        });
    });
});

// Mobile menu toggle
const mobileMenuToggle = () => {
    const navLinks = document.querySelector('.nav-links');
    navLinks.classList.toggle('active');
};

// Cart functionality
let cart = [];
const cartCount = document.querySelector('.cart-count');

const updateCartCount = () => {
    cartCount.textContent = cart.length;
};

// Sample menu items (in a real application, this would come from a database)
const menuItems = {
    appetizers: [
        { id: 1, name: 'Spring Rolls', price: 8.99, description: 'Crispy vegetable spring rolls with sweet chili sauce' },
        { id: 2, name: 'Edamame', price: 5.99, description: 'Steamed soybeans with sea salt' }
    ],
    mainCourses: [
        { id: 3, name: 'Pad Thai', price: 12.99, description: 'Stir-fried rice noodles with egg, vegetables and peanuts' },
        { id: 4, name: 'Sushi Platter', price: 24.99, description: 'Assorted fresh sushi with wasabi and soy sauce' }
    ],
    beverages: [
        { id: 5, name: 'Green Tea', price: 3.99, description: 'Traditional Japanese green tea' },
        { id: 6, name: 'Thai Iced Tea', price: 4.99, description: 'Sweet and creamy Thai iced tea' }
    ]
};

// Load menu items
const loadMenuItems = () => {
    const menuCategories = document.querySelectorAll('.menu-items');
    
    Object.entries(menuItems).forEach(([category, items], index) => {
        const menuContainer = menuCategories[index];
        items.forEach(item => {
            const menuItem = document.createElement('div');
            menuItem.className = 'menu-item';
            menuItem.innerHTML = `
                <h4>${item.name}</h4>
                <p>${item.description}</p>
                <p class="price">$${item.price.toFixed(2)}</p>
                <button onclick="addToCart(${item.id})">Add to Cart</button>
            `;
            menuContainer.appendChild(menuItem);
        });
    });
};

// Add to cart function
const addToCart = (itemId) => {
    // Find the item in all categories
    let selectedItem = null;
    Object.values(menuItems).forEach(category => {
        const item = category.find(i => i.id === itemId);
        if (item) selectedItem = item;
    });

    if (selectedItem) {
        cart.push(selectedItem);
        updateCartCount();
        // Show notification
        showNotification(`${selectedItem.name} added to cart!`);
    }
};

// Show notification
const showNotification = (message) => {
    const notification = document.createElement('div');
    notification.className = 'notification';
    notification.textContent = message;
    document.body.appendChild(notification);

    setTimeout(() => {
        notification.remove();
    }, 3000);
};

// Initialize the page
document.addEventListener('DOMContentLoaded', () => {
    loadMenuItems();
    updateCartCount();
});

// Form submission handling
const contactForm = document.querySelector('.contact-form form');
if (contactForm) {
    contactForm.addEventListener('submit', (e) => {
        e.preventDefault();
        // Here you would typically send the form data to a server
        showNotification('Thank you for your message! We will get back to you soon.');
        contactForm.reset();
    });
}

document.addEventListener('DOMContentLoaded', function() {
    // Mobile menu toggle
    const mobileMenuToggle = document.querySelector('.mobile-menu-toggle');
    const navLinks = document.querySelector('.nav-links');
    
    if (mobileMenuToggle && navLinks) {
        mobileMenuToggle.addEventListener('click', function() {
            this.classList.toggle('active');
            navLinks.classList.toggle('active');
            document.body.style.overflow = navLinks.classList.contains('active') ? 'hidden' : '';
        });

        // Close mobile menu when clicking outside
        document.addEventListener('click', function(e) {
            if (!mobileMenuToggle.contains(e.target) && !navLinks.contains(e.target) && navLinks.classList.contains('active')) {
                mobileMenuToggle.classList.remove('active');
                navLinks.classList.remove('active');
                document.body.style.overflow = '';
            }
        });

        // Close mobile menu when clicking on a link
        navLinks.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                mobileMenuToggle.classList.remove('active');
                navLinks.classList.remove('active');
                document.body.style.overflow = '';
            });
        });
    }

    // Add padding to body to account for fixed header
    const header = document.querySelector('.header');
    if (header) {
        document.body.style.paddingTop = header.offsetHeight + 'px';
    }
}); 