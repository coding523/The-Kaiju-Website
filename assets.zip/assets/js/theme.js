// Theme handling
const setTheme = (theme) => {
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem('theme', theme);
};

const toggleTheme = () => {
    const currentTheme = localStorage.getItem('theme') || 'light';
    const newTheme = currentTheme === 'light' ? 'dark' : 'light';
    setTheme(newTheme);
};

// Auto switch theme based on time
const autoTheme = () => {
    const hour = new Date().getHours();
    const theme = hour >= 6 && hour < 18 ? 'light' : 'dark'; // Light theme from 6 AM to 6 PM
    setTheme(theme);
};

// Initialize theme
const initTheme = () => {
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme) {
        setTheme(savedTheme);
    } else {
        autoTheme();
    }
};

// Page transitions
const initPageTransitions = () => {
    document.body.classList.add('page-transition');
    
    // Handle navigation transitions
    document.querySelectorAll('a').forEach(link => {
        link.addEventListener('click', (e) => {
            const isInternalLink = link.href.includes(window.location.origin);
            if (isInternalLink) {
                e.preventDefault();
                document.body.style.opacity = 0;
                setTimeout(() => {
                    window.location.href = link.href;
                }, 500);
            }
        });
    });
};

// Scroll animations
const initScrollAnimations = () => {
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px'
    };

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animate');
                observer.unobserve(entry.target);
            }
        });
    }, observerOptions);

    // Add animation classes to elements
    document.querySelectorAll('.menu-item, .category, .about-content, .location-content, .contact-form')
        .forEach(el => {
            el.classList.add('animate-on-scroll');
            observer.observe(el);
        });
};

// Particle animation for hero section
const initParticles = () => {
    const hero = document.querySelector('.hero');
    if (!hero) return;

    for (let i = 0; i < 50; i++) {
        const particle = document.createElement('div');
        particle.className = 'particle';
        particle.style.setProperty('--delay', `${Math.random() * 5}s`);
        particle.style.setProperty('--size', `${Math.random() * 3 + 1}px`);
        hero.appendChild(particle);
    }
};

// Initialize everything when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    initTheme();
    initPageTransitions();
    initScrollAnimations();
    initParticles();

    // Add theme toggle button
    const themeToggle = document.createElement('button');
    themeToggle.className = 'theme-toggle';
    themeToggle.innerHTML = '🌓';
    themeToggle.addEventListener('click', toggleTheme);
    document.body.appendChild(themeToggle);

    // Check theme every hour
    setInterval(autoTheme, 3600000);
});

// Add CSS for particle animation
const style = document.createElement('style');
style.textContent = `
    .particle {
        position: absolute;
        width: var(--size);
        height: var(--size);
        background: white;
        border-radius: 50%;
        pointer-events: none;
        opacity: 0;
        animation: float 5s ease-in-out var(--delay) infinite;
    }

    @keyframes float {
        0%, 100% {
            transform: translateY(0) translateX(0);
            opacity: 0;
        }
        25% {
            opacity: 0.8;
        }
        50% {
            transform: translateY(-100vh) translateX(100px);
            opacity: 0;
        }
    }

    .animate-on-scroll {
        opacity: 0;
        transform: translateY(30px);
        transition: all 0.8s ease-out;
    }

    .animate-on-scroll.animate {
        opacity: 1;
        transform: translateY(0);
    }
`;
document.head.appendChild(style); 